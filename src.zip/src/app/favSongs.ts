export class favSongs
 { 
     songName: string;  artist: string; genre: string; year: string ;picture: string;
}