import { Component, OnInit } from '@angular/core';
import { favSongs } from '../favSongs';
import { MYSONGS } from 'src/assets/data/mySongs';



@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

   mySongs= MYSONGS;
  classPicked: favSongs;
  

  constructor() { }

  ngOnInit() {
    this.onClick(0);
    
  }


  ngAfterViewInit() {
    var list = document.getElementById("myList").getElementsByTagName("div");
    for (let x=0; x < list.length; x++) {
      list[x].style.display = "none";
    }
  }

  clickMe(index) {
    var list = document.getElementById("myList").getElementsByTagName("div");

    if (list[index].style.display == 'none'){
      list[index].style.display = 'block';
    } 
    else {
      list[index].style.display = 'none';
    }  
  }

  onClick(index){
    this.classPicked = {
      songName: this.mySongs[index].songName,
      artist: this.mySongs[index].artist,   
      genre: this.mySongs[index].genre,
      year: this.mySongs[index].year, 
      picture: this.mySongs[index].picture   
    }
  }
}