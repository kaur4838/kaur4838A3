export class kaur4838 { sid: string; sname: string;  scampus: string; slogin: string; stitle: string;}
