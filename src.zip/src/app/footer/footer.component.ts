import { Component, OnInit } from '@angular/core';
import { kaur4838 } from '../kaur4838' ;

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  currUser: kaur4838 = {sid: "991502021", sname: "Gurmehak Kaur",  
    scampus: "Davis", slogin: "kaur4838", stitle: "Assignment3" 
  }

  constructor() { }

  ngOnInit() {
  }

}
