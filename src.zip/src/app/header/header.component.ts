import{Component,OnInit} from '@angular/core';

import {kaur4838} from '../kaur4838'; 

@Component({
    selector: 'app-header',
    templateUrl:'./header.component.html',
    styleUrls:['./header.component.css']
})
export class HeaderComponent implements OnInit {
    currUser: kaur4838 = {
        sid: "991502021", sname: "Gurmehak Kaur",  
    scampus: "Davis", slogin: "kaur4838", stitle: "Assignment3"
}


 constructor(){}
 ngOnInit(){

 }
}