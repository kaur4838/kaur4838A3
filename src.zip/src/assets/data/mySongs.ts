import { favSongs } from '../../app/favSongs';
export const MYSONGS: favSongs[]=
[
    {songName: 'bol do na zra',artist: 'Armaan Malik', genre:'Romantic song' , year: '2018' , picture: "assets/images/bol.jpg" },
    {songName: 'Itni Si Baat Hain',artist: 'Arijit Singh', genre:'Sad song' , year: '2018' , picture: "assets/images/itni.jpg"}, 
    {songName: 'Tu Hi Na Jaane',artist: 'Sonu Nigam', genre:'Romantic song' , year: '2018' , picture: "assets/images/Tu.jpg"},
    {songName: 'Jeetne Ke Liye',artist: 'Krishnakumar Kunnath', genre:'Sad song' , year: '2018' , picture: "assets/images/Jeetna.jpg"}
]